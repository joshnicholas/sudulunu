# A bunch of helper scripts

This is pretty much entirely for my own use so I'm not going to write any docs. There's a bunch of helper scripts for things I often need to do with pandas/merging/fuzzymatching/working with local files. 



